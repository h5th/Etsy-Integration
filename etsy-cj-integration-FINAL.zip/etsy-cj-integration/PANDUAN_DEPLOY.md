# Panduan Deploy: Etsy → CJ Dropshipping Auto-Forward

## Apa yang kamu dapatkan?

Aplikasi web yang berjalan 24 jam otomatis:
- Cek order baru di Etsy setiap 15 menit
- Teruskan order ke CJ Dropshipping secara otomatis
- Dashboard untuk monitor semua order
- SKU Mapping yang tersimpan permanen

**Biaya: GRATIS** (menggunakan Render.com free tier)

---

## LANGKAH 1 — Buat Akun GitHub (kalau belum punya)

1. Buka https://github.com
2. Klik **Sign up**
3. Daftar dengan email kamu
4. Verifikasi email

---

## LANGKAH 2 — Upload Kode ke GitHub

### 2a. Buat repository baru

1. Login ke GitHub
2. Klik tombol **"+"** di pojok kanan atas → **New repository**
3. Isi nama: `etsy-cj-integration`
4. Pilih **Private** (supaya API key lebih aman)
5. Klik **Create repository**

### 2b. Upload file

Setelah repository dibuat, kamu akan melihat halaman kosong. Klik **"uploading an existing file"**

1. Extract file **etsy-cj-integration.zip** yang sudah kamu download
2. Drag & drop **semua isi folder** (bukan folder-nya, tapi isi dalamnya):
   - `server.js`
   - `package.json`
   - `.gitignore`
   - folder `public/` beserta isinya
3. Klik **Commit changes**

---

## LANGKAH 3 — Deploy ke Render.com (GRATIS)

### 3a. Buat akun Render

1. Buka https://render.com
2. Klik **Get Started for Free**
3. Pilih **Sign up with GitHub** (paling mudah)
4. Authorize Render untuk akses GitHub kamu

### 3b. Buat Web Service baru

1. Di dashboard Render, klik **New +** → **Web Service**
2. Pilih **Build and deploy from a Git repository**
3. Klik **Connect** di sebelah repository `etsy-cj-integration` yang tadi kamu buat
4. Isi form berikut:

| Field | Isi |
|-------|-----|
| Name | etsy-cj-integration |
| Region | Singapore (paling dekat) |
| Branch | main |
| Runtime | Node |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Instance Type | **Free** |

5. Klik **Create Web Service**
6. Tunggu sekitar 2-3 menit sampai deploy selesai (status: **Live**)

### 3c. Catat URL aplikasi kamu

Setelah deploy selesai, Render akan memberikan URL seperti:
```
https://etsy-cj-integration.onrender.com
```
**Simpan URL ini** — ini adalah alamat dashboard kamu!

---

## LANGKAH 4 — Setup API Keys di Dashboard

1. Buka URL aplikasi kamu di browser
2. Klik tab **API Keys**
3. Isi form:

**Etsy API:**
- **Etsy API Key** → Keystring dari https://www.etsy.com/developers/your-apps
- **Etsy Shop ID** → Bisa dilihat di URL toko kamu atau di Etsy Developer dashboard
- **Etsy Access Token** → OAuth token dari Etsy Developer

**CJ Dropshipping:**
- **Email** → Email login akun CJ Dropshipping kamu
- **Password** → Password akun CJ Dropshipping kamu

4. Klik **Simpan Settings**
5. Klik **Tes Koneksi** untuk memastikan keduanya terhubung ✓

---

## LANGKAH 5 — Setup SKU Mapping

1. Klik tab **SKU Mapping**
2. Untuk setiap produk pin/brooch kamu:
   - **SKU Etsy** → SKU produk di Etsy (cek di Listings → Edit → Variations)
   - **CJ Product ID** → Product ID dari CJ Dropshipping
   - **CJ SKU/VID** → SKU atau Variant ID dari CJ (opsional tapi disarankan)
3. Klik **+ Tambah** untuk setiap produk

---

## LANGKAH 6 — Aktifkan Auto-Forward

1. Kembali ke tab **Dashboard**
2. Nyalakan toggle **"Auto-forward setiap 15 menit"**
3. Selesai! 🎉

Aplikasi sekarang akan otomatis:
- Cek order baru di Etsy setiap 15 menit
- Teruskan order ke CJ Dropshipping
- Catat semua aktivitas di tab Log

---

## Cara Mendapatkan Etsy API Keys

1. Buka https://www.etsy.com/developers/your-apps
2. Klik **Create a New App**
3. Isi nama app (contoh: "My CJ Integration")
4. Setelah dibuat, kamu dapat **Keystring** dan **Shared Secret**
5. Untuk **Access Token**, kamu perlu OAuth flow:
   - Di halaman app, klik **Request an OAuth token**
   - Ikuti langkah-langkahnya
   - Simpan token yang dihasilkan

---

## Cara Mendapatkan CJ Dropshipping API

Aplikasi ini menggunakan email + password CJ kamu langsung (sama seperti login di website CJ). Tidak perlu API key terpisah.

Jika ingin lebih aman, CJ juga menyediakan API key resmi di:
Dashboard CJ → **My CJ** → **API** → **Get Access Token**

---

## Catatan Penting

**Render Free Tier:**
- Server akan "tidur" setelah 15 menit tidak ada aktivitas
- Saat ada request masuk, server akan "bangun" lagi (butuh ~30 detik)
- Auto-cron order tetap berjalan selama ada aktivitas rutin

**Supaya server tidak tidur:**
- Buka dashboard minimal sekali sehari, ATAU
- Gunakan layanan gratis seperti https://cron-job.org untuk ping URL kamu setiap 10 menit

**Keamanan:**
- Data (API keys, mappings, orders) disimpan di file `data.json` di server Render
- Untuk keamanan lebih, gunakan Render Environment Variables (hubungi saya untuk panduan ini)

---

## Butuh Bantuan?

Jika ada error atau kendala, screenshot pesan error-nya dan tanyakan ke Claude. Sebutkan di langkah mana kamu mengalami masalah.
